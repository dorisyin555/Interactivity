let ax, ay, ar, adx, ady
let bx, by, br, bdx, bdy

function setup() {
  createCanvas(400, 400);
  ellipseMode(RADIUS)
  ax = random(width)
  ay = random(height)
  ar = random(30,20)
  adx = random(-5,5)
  ady = random(-5,5)
  bx = random(width)
  by = random(height)
  br = random(30,20)
  bdx = random(-5,5)
  bdy = random(-5,5)
}

function draw() {
  background(220);
  fill("green")
  circle(ax,ay,ar)
  fill("blue")
  circle(bx,by,br)
  ax = ax + adx
  ay = ay + ady
  bx = bx + bdx
  by = ay + bdy
  
  if(ax < 0 || ax > width) {
    adx = adx * -1
  }
  
  if(ay < 0 || ay > height) {
  ady = ady * -1
  }
  
  if(bx < 0 || bx > width) {
  bdx = bdx * -1
  }
  
  if(by < 0 || by > width) {
  bdy = bdy * -1
  }
  
  if(dist(ax,ay,bx,by) <ar + br) {
    let temp = adx
    adx = bdx
    bdx = temp
    
    temp = ady
    ady = bdy
    bdy = temp
  }
}